import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class SiriClient {

    private static final String HOST = "localhost";
    private static final int    PORT = 12345;
    private static final String KEY  = "TMU";   // must match server

    public static void main(String[] args) {
        try (Socket socket = new Socket(HOST, PORT);
             BufferedReader in = new BufferedReader(
                     new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             Scanner scanner = new Scanner(System.in)) {

            System.out.println("Connected to Siri server at " + HOST + ":" + PORT);
            System.out.println("Type your question (empty line to quit):\n");

            while (true) {
                System.out.print("Q: ");
                String line = scanner.nextLine();
                if (line.trim().isEmpty()) break;

                String cipherQ = VigenereCipher.encrypt(line, KEY);
                System.out.println("[Encrypted question: " + cipherQ + "]");
                out.println(cipherQ);

                String cipherA = in.readLine();
                if (cipherA == null) break;
                System.out.println("[Encrypted answer: " + cipherA + "]");

                String plainA = VigenereCipher.decrypt(cipherA, KEY);
                System.out.println("A: " + plainA + "\n");
            }
            System.out.println("Client shutting down.");
        } catch (IOException e) {
            System.err.println("Client error: " + e.getMessage());
        }
    }
}