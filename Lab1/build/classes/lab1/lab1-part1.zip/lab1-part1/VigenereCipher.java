/**
 * Utility class for Vigenère encryption/decryption.
 * Only alphabetic characters (A-Z, a-z) are transformed; everything else is copied as-is.
 */
public final class VigenereCipher {

    private VigenereCipher() { } // prevent instantiation

    /**
     * Encrypts plaintext with the given keyword using the classic Vigenère cipher.
     */
    public static String encrypt(String plaintext, String keyword) {
        StringBuilder encrypted = new StringBuilder();

        for (int i = 0, j = 0; i < plaintext.length(); i++) {
            char c = plaintext.charAt(i);

            if (Character.isUpperCase(c)) {
                int shift = Character.toUpperCase(keyword.charAt(j % keyword.length())) - 'A';
                char enc  = (char) (((c - 'A') + shift) % 26 + 'A');
                encrypted.append(enc);
                j++;
            } else if (Character.isLowerCase(c)) {
                int shift = Character.toUpperCase(keyword.charAt(j % keyword.length())) - 'A';
                char enc  = (char) (((c - 'a') + shift) % 26 + 'a');
                encrypted.append(enc);
                j++;
            } else {
                encrypted.append(c); // non-alphabetic: copy unchanged
            }
        }
        return encrypted.toString();
    }

    /**
     * Decrypts ciphertext that was produced by the same keyword.
     */
    public static String decrypt(String ciphertext, String keyword) {
        StringBuilder decrypted = new StringBuilder();

        for (int i = 0, j = 0; i < ciphertext.length(); i++) {
            char c = ciphertext.charAt(i);

            if (Character.isUpperCase(c)) {
                int shift = Character.toUpperCase(keyword.charAt(j % keyword.length())) - 'A';
                char dec  = (char) (((c - 'A' - shift + 26) % 26) + 'A');
                decrypted.append(dec);
                j++;
            } else if (Character.isLowerCase(c)) {
                int shift = Character.toUpperCase(keyword.charAt(j % keyword.length())) - 'A';
                char dec  = (char) (((c - 'a' - shift + 26) % 26) + 'a');
                decrypted.append(dec);
                j++;
            } else {
                decrypted.append(c); // non-alphabetic: copy unchanged
            }
        }
        return decrypted.toString();
    }
}