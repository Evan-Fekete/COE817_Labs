import java.io.*;
import java.net.*;
import java.util.*;

public class SiriServer {

    private static final int PORT = 12345;
    private static final String KEY = "TMU";

    /* ---------------- Q/A database ---------------- */
    private static final Map<String, String> ANSWERS = Map.of(
            "who created you",      "I was created by Apple.",
            "what does siri mean",  "victory and beautiful",
            "are you a robot",      "I am a virtual assistant."
    );

    public static void main(String[] args) {
        System.out.println("SiriServer listening on port " + PORT);
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {               // handle one client at a time
                try (Socket client = serverSocket.accept();
                     BufferedReader in = new BufferedReader(
                             new InputStreamReader(client.getInputStream()));
                     PrintWriter out = new PrintWriter(
                             client.getOutputStream(), true)) {

                    System.out.println("Client connected: " + client.getRemoteSocketAddress());

                    String cipherQ;
                    while ((cipherQ = in.readLine()) != null) {
                        System.out.println("Received ciphertext: " + cipherQ);
                        String plainQ = VigenereCipher.decrypt(cipherQ, KEY).trim();
                        System.out.println("Decrypted question  : " + plainQ);

                        String lookupKey = plainQ.toLowerCase(Locale.ROOT)
                                               .replaceAll("[^a-z0-9 ]", "")
                                               .trim();
                        String plainA = ANSWERS.getOrDefault(lookupKey,
                                "Sorry, I don't understand the question.");
                        String cipherA = VigenereCipher.encrypt(plainA, KEY);
                        System.out.println("Sending ciphertext  : " + cipherA);
                        out.println(cipherA);
                    }
                    System.out.println("Client disconnected.");
                } catch (IOException e) {
                    System.err.println("Handler error: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }
}